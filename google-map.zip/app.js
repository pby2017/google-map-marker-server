var express = require('express');
var app = express();
var bodyParser = require('body-parser');
require('dotenv').config();
var googleMapsClient = require('@google/maps').createClient({
    key: process.env.API_KEY
});

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(express.static('./'));

app.post('/testcfc', function (req, res) {

    // Latitude 값 받아옴
    console.log(req.body.Latitude);

    // Longitude 값 받아옴
    console.log(req.body.Longitude);

    /* post로 받는 console.log 결과 
    37.27927927927928
    127.08063325297499

    이 값을 index.html의 var marker = new google.maps.Marker 의 position 값에 어떻게 전달할까요..
    */

    res.send('');
});

app.listen(3000, function () {
    console.log('server start');
    console.log(windows.document.getElementById('map'));
});